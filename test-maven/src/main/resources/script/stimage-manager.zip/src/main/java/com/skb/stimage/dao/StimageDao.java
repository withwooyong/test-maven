package com.skb.stimage.dao;

public class StimageDao {

}
