package com.skb.stimage.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.skb.stimage.dao.DBMapper;

@Service
public class DBService {
	
	@Autowired
	DBMapper dbMapper;

	public String now() throws Exception {
		return dbMapper.now();
	}

	public String now2() throws Exception {
		return dbMapper.now2();
	}
}
