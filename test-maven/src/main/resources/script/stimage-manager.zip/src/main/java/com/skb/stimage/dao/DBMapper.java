package com.skb.stimage.dao;

import org.apache.ibatis.annotations.Select;

public interface DBMapper {

	public String now() throws Exception;

	@Select("SELECT NOW()")
	public String now2();
}
