package com.skb.stimage.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.skb.stimage.service.DBService;

@Controller
public class StimageController {

	private static final Logger log = LoggerFactory.getLogger(StimageController.class);

	@Autowired
	DBService dbService;

	@RequestMapping("/")
	public String index() throws Exception {
		
		System.out.println("index================>");
		return "Hello World";
	}

	@RequestMapping("/welcome")
	public String welcome(Map<String, Object> model) {
		System.out.println("welcome===============");
		model.put("message", "welcome message");
		return "welcome";
	}

	@RequestMapping("/now")
	public @ResponseBody String now() throws Exception {
		System.out.println("now===============");
		return dbService.now();
	}

	@RequestMapping("/now2")
	public @ResponseBody String now2() throws Exception {
		System.out.println("now2===============");
		return dbService.now2();
	}
}
