package com.skb.stimage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.skb.dao"})
@EntityScan("com.skb.domain")
public class StimageManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(StimageManagerApplication.class, args);
	}
}
